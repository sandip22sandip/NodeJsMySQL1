const express = require('express');
let app = express();
require("dotenv").config();
let bodyParser = require('body-parser');
app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());

require('./routes')(app);
// app.get('/', (req, res) => res.send("Welcome"));
app.listen(process.env.PORT, (err) => {
    if(err)throw err;
    console.log(`Application listening on port ${process.env.PORT}`);
});