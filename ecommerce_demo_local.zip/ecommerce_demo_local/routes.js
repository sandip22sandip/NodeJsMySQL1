let registrationRoutes = require("./app/routes/registration.routes");
let loginRoutes = require("./app/routes/login.routes");
let changepasswordRoutes = require("./app/routes/changepassword.routes");
let productRoutes = require("./app/routes/product.routes");

module.exports = (app) => {
  app.use("/api/v1/", registrationRoutes);
  app.use("/api/v1/", loginRoutes);
  app.use("/api/v1/", changepasswordRoutes);
  app.use("/api/v1/", productRoutes);
};
