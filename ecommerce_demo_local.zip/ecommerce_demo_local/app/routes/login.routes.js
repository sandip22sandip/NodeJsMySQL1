var express = require("express");
var router = express.Router();
const loginController = require("../controller/login.controller");
const validator = require("../validation/field.validation");
const Authentication=require("../helper/auth.helper");

/* login router lising. */
router.post("/login", validator.validate("login"), loginController.login);
// router.get("/getLoginUser",Authentication.ensure ,loginController.getLoginUser);

module.exports = router;
