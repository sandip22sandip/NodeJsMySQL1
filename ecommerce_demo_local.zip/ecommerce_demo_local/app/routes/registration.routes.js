var express = require("express");
var router = express.Router();
const registraionController = require("../controller/registration.controller");
const getAlluserController = require("../controller/getAlluser.controller");
const validator=require("../validation/field.validation");
const Authentication=require("../helper/auth.helper");
/* registration router lising. */
router.post("/self-registration",validator.validate("registration"), registraionController.registration);
router.post("/admin-registration",Authentication.ensure,Authentication.authorize,validator.validate("registration"), registraionController.registration);
router.get("/getAlluser",Authentication.ensure,Authentication.authorize,getAlluserController.getAllUser);

module.exports = router;