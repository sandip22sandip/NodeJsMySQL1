var express = require("express");
var router = express.Router();
const validator=require("../validation/field.validation");
const changepasswordController = require("../controller/changepassword.controller");
const Authentication = require("../helper/auth.helper");

/* changepassword router lising. */
router.put("/changepassword/:id",Authentication.ensure,validator.validate("changepassword"),changepasswordController.changePassword);

module.exports = router;