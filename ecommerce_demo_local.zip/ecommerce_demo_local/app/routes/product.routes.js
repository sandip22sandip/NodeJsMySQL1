var express = require("express");
var router = express.Router();
const productController = require("../controller/product.controller");
const viewAllproductController = require("../controller/viewAllproduct.controller");
const viewProductByIdController = require("../controller/viewProductById.controller");
const deleteProductByIdController = require("../controller/deleteProductById.controller");
const updateProductByIdController = require("../controller/updateProductById.controller");
const Authentication = require("../helper/auth.helper");
const imageUploader=require('../helper/imageUploder.helper');

/* changepassword router lising. */

router.post("/addProduct",Authentication.ensure,imageUploader.upload.array('product_image',3),productController.addProduct);
router.get("/viewAllproduct",Authentication.ensure,viewAllproductController.viewAllproduct);
router.get("/viewProductById/:product_id",Authentication.ensure,viewProductByIdController.viewProductById);
router.put("/updateProductById/:product_id",Authentication.ensure,imageUploader.upload.array('product_image',3),updateProductByIdController.updateProductById);
router.delete("/deleteProductById/:product_id",Authentication.ensure,deleteProductByIdController.deleteProductById);

module.exports = router;