require("dotenv").config();
const bcrypt = require("bcrypt");
const Helper = require("../helper/common.helper");
// const Auth=require("../helper/auth.helper");
const db = require("../model/sequelize.model");
const { validationResult } = require("express-validator");
const jwt = require("jsonwebtoken");
const loginModel = db.registrationModel;

module.exports = {
  login: async (req, res) => {
    try {
      //it use to showing validation error message.
      const errors = validationResult(req);
      if (!errors.isEmpty()) {
        return Helper.handleError(
          res,
          400,
          "Required inputs are invalid.",
          false,
          { error: errors.array() }
        );
      }

      //get email and password from the body.
      const { email, password } = req.body;
      //get login details from the database.
      const loginDetails = await loginModel.findOne({
        where: {
          email,
        },
      });
      //check login details exits or not,if not then show above message.
      if (!loginDetails) {
        return Helper.respondAsJSON(
          res,
          "Email not match with system.",
          email,
          false,
          404
        );
      }

      //get data from logindetails.
      let { id, first_name, last_name, gender, contact_no, role_id, status } =
        loginDetails;
      //compare password with database.
      if (bcrypt.compareSync(password, loginDetails.password)) {
        //create token
        const token = jwt.sign(
          {
            id,
            first_name,
            last_name,
            email,
            gender,
            contact_no,
            password,
            role_id,
            status,
          },
          process.env.JWT_KEY,
          { expiresIn: "1hr" }
        );
        //update token in database
        loginDetails.token = token;
        //check token update or not.
        if (await loginDetails.save()) {
          //delete password from the object.
          delete loginDetails.dataValues.password;
          return Helper.respondAsJSON(
            res,
            "Login successfully.",
            loginDetails,
            true,
            200
          );
        } else {
          return Helper.respondAsJSON(res, "Login fail.", "", false, 401);
        }
      } else {
        return Helper.respondAsJSON(
          res,
          "Password not match with system.",
          password,
          false,
          401
        );
      }
    } catch (error) {
      console.log(error);
      return Helper.respondAsJSON(res, "Unable to login.", error, false, 500);
    }
  },
  // getLoginUser: async (req,res)=>{
  //   try {
  //     const tokenData=await Auth.getUserData(req);
  //     if(tokenData===null){
  //       return Helper.respondAsJSON(res,"please Login(login Expiry.).",error,false,500);
  //     }
  //     const data={};
  //     data.first_name=tokenData.first_name;
  //     data.last_name=tokenData.last_name;
  //     data.type=tokenData.type;
  //     return Helper.respondAsJSON(res,"Get login user data.",data,true,200);
  //   } catch (error) {
  //     console.log(error);
  //       return Helper.respondAsJSON(res,"Unable to get Data.",error,false,500);
  //   }
  // },
};
