require("dotenv").config;
const Helper = require("../helper/common.helper");
const db = require("../model/sequelize.model");
const Auth=require("../helper/auth.helper");
const registrationModel = db.registrationModel;
const rolesModel = db.roleModel;
module.exports={
    getAllUser:async (req,res)=>{
        try {
            let {page_no}=req.body;
            let offset = 0;
            offset = process.env.DOCSLIMIT * (page_no - 1);
            // const count=await registrationModel.count();
            // console.log("TotalRecords",count);
            const pages=await Helper.countPages(registrationModel);
            const getAlluserData= await registrationModel.findAll({
                limit:parseInt(process.env.DOCSLIMIT),
                offset: offset,
                attributes: { exclude: ['password'] },
                include:[{model:rolesModel}]
            });
            if(getAlluserData.length>0){
                return Helper.respondAsJSON(res,"User fatch successfully.",getAlluserData,true,200,pages);
            }
            return Helper.respondAsJSON(res,"No data found.",getAlluserData,false,404); 
        } catch (error) {
            console.error("error while catch",error);
            return Helper.handleError(res,500,'Unable to registration',false,error);
        }
    }
}