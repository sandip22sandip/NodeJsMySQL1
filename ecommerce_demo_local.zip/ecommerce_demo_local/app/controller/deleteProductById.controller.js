require("dotenv").config();
const Helper=require("../helper/common.helper");
const db = require("../model/sequelize.model");
const productModel=db.productModel;

module.exports={
    deleteProductById: async (req,res)=>{
        try {
            let {product_id}=req.params;
            const productData=await productModel.findByPk(product_id);
            //update product status
            productData.status=9;
            //check product status update or not.
            if(await productData.save()){
                return Helper.respondAsJSON(res,"Product delete successfully.",productData,true,200);
            }
            return Helper.respondAsJSON(res,"Product not delete yet.",productData,false,404);
        } catch (error) {
            console.error("error while catch",error);
            return Helper.handleError(res,500,'Unable to delete product.',false,error);
        }
    },
}