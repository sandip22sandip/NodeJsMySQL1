require("dotenv").config();
let {Sequelize,Op, where}=require('sequelize');
const Helper=require("../helper/common.helper");
const Auth=require("../helper/auth.helper");
const db = require("../model/sequelize.model");
const productModel=db.productModel;
const registrationModel=db.registrationModel;
module.exports={
    addProduct:async (req,res)=>{
        try {
           //get data from the token.
            const data=await Auth.getUserData(req);
            if(!data){
                return Helper.respondAsJSON(res,"Please Login !..",data,false,401);
            }
            
            if(data.type=="vendor"){
                let {product_name,brand_name,product_details,product_rating,product_price,status}=req.body;
                const addproductData=await productModel.build({
                    product_name,
                    brand_name,
                    product_details,
                    product_rating,
                    product_price,
                    id:data.id,
                    status,
                });
                await addproductData.save();
                const path = [];
                Object.keys(req.files).forEach((k) => {
                    const file = req.files[k];
                    const product_id=addproductData.dataValues.product_id;
                    const value = { file,product_id};
                    path.push(value);
                });
                // path.map(v=>(console.log(v)));
                const addImage= await db.imageModel.bulkCreate(path.map(v=>({url:v.file.path,product_id:v.product_id})));
                if(!await addproductData.save() && !addImage){
                    return Helper.respondAsJSON(res,"Product not added yet.",addproductData,false,500);
                }
                return Helper.respondAsJSON(res,"Product added successfully.",addproductData,true,200);
            }else{
                return Helper.respondAsJSON(res,"You are not vendor,(Only vendor can add products.).","",false,500);
            }
        } catch (error) {
            console.log("error in catch",error);
            return Helper.handleError(res,500,'Unable to add product',false,error);
        }
    },
    
}