require("dotenv").config();
let {Sequelize,Op}=require('sequelize');
const Helper=require("../helper/common.helper");
const Auth=require("../helper/auth.helper");
const db = require("../model/sequelize.model");
const productModel=db.productModel;
const registrationModel=db.registrationModel;
const imageModel=db.imageModel;

module.exports={
 viewAllproduct:async (req,res)=>{
    try {
        const tokendata=await Auth.getUserData(req);
        if(!tokendata){
            return Helper.respondAsJSON(res,"Please Login !..",tokendata,false,401);
        }
        let {page_no}=req.body;
        let offset = 0;
        offset = process.env.DOCSLIMIT * (page_no - 1);
        let {product_name,brand_name} = req.query;
        //it use to product search by name in req.query.
        let product = { where: {},order:{}};
        //it use to in include query.
        let registration = { where: {}};
        if(product_name){
            product.where=product_name ? { product_name: { [Op.like]: `%${product_name}%` } } : null;
        }
        if(brand_name){
            product.where=brand_name ? { brand_name: { [Op.like]: `%${brand_name}%` } } : null;
        }
        if(tokendata.type=="user"){
            product.where.status=1;
            product.order=["product_id", "DESC"];
        }
        if(tokendata.type==='vendor'){
            registration.where.id=tokendata.id;
            product.order=["product_id", "ASC"];
        }
        let query = {
            limit:parseInt(process.env.DOCSLIMIT),
            offset: offset,
            where: [product.where],
            include: [{
                model:imageModel,
            },{
                model: registrationModel,
                attributes: { exclude: ['password'] },
                where: [registration.where]
            }],
            order: [product.order],
        };
        const productData=await productModel.findAll({query});
        const pages=await Helper.countPages(productModel);
        if(!productData.length){
            return Helper.respondAsJSON(res,"Product not found yet.",productData,false,404,pages);
        }
        return Helper.respondAsJSON(res,"Product View successfully.",productData,true,200,pages);
    } catch (error) {
        console.error("error in catch",error);
        return Helper.handleError(res,500,'Unable to view product.',false,error);
    }
}
}