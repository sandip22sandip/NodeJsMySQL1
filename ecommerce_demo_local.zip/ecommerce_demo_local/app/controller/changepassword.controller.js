require("dotenv").config();
const bcrypt = require("bcrypt");
const db = require("../model/sequelize.model");
const{validationResult}=require("express-validator");
// const Auth=require("../helper/auth.helper");
const Helper=require("../helper/common.helper");
const changepasswordModel = db.registrationModel;

module.exports={
    changePassword: async(req,res)=>{
        try {
            const errors=validationResult(req);
            if(!errors.isEmpty()){
                return Helper.handleError(res,400,"Required inputs are invalid.",false,{error:errors.array()});
            }

            //check data is available or not using where token condition.
            let {id}=req.params;
            let data= await changepasswordModel.findByPk(id);
            if(!data){
                return Helper.respondAsJSON(res,"No data found(you must login again).",data,false,404);
            }
            const {newpassword,oldpassword}=req.body;
            //check oldpassword with system.
            if(!bcrypt.compareSync(oldpassword,data.password)){
                return res.status(404).json({status:false,msg:"Password not match with system(Please enter correct password.)"});
            }
            //check old password and new password.
            if(bcrypt.compareSync(newpassword,data.password)){
                return Helper.respondAsJSON(res,"Old Password & New Password is same.","",false,401);
            }else{
                const updatePassword=await changepasswordModel.update({
                    password:bcrypt.hashSync(newpassword,10),
                },{
                    where:{
                       id,
                    }
                });
                //check password is update or not.
                if(!updatePassword){
                    return Helper.respondAsJSON(res,"Password not changed.",updatePassword,false,401);
                }
                delete data.dataValues.password;
                return Helper.respondAsJSON(res,"Password change successfully.",data,true,200);
            }       
        } catch (error) {
            console.log(error);
            return Helper.respondAsJSON(res,"Unable to changepassword.",error,false,500);
        }
    }
}