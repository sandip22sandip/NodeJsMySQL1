const bcrypt = require("bcrypt");
const Helper = require("../helper/common.helper");
const Auth = require("../helper/auth.helper");
const { validationResult } = require("express-validator");
const db = require("../model/sequelize.model");
const registrationModel = db.registrationModel;

module.exports = {
  registration: async (req, res) => {
    try {
      //this is use for show a validation error message.
      const errors = validationResult(req);
      if (!errors.isEmpty()) {
        return Helper.handleError(res,400,"Required inputs are invalid.",false,{ error: errors.array() });
      }
      //get all field from body.
      let {first_name, last_name, email, gender, contact_no, role} = req.body;
      const isemailExist = await registrationModel.findAll({
        where: {
          email,
        },
      });
      //show message if email exits.
      if (isemailExist.length) {
        return Helper.respondAsJSON(res,"Email already taken(Please use different email).",email,false,401);
      }
      //convert password in encrpt.
      const password = bcrypt.hashSync(req.body.password, 10);
      //check role and set value.
      if(role=="Admin"){
        role_id=1;
      }
      if(role=="User"){
        role_id=2;
      }
      if(role=="Vendor"){
        role_id=3;
      }

      const query={
        first_name,
        last_name,
        email,
        gender,
        contact_no,
        password,
        role_id,
      };
      const Registration = await registrationModel.build(query);
      //check data saved or not in databse.
      if (await Registration.save()) {

        delete Registration.dataValues.password;
        //started for user.
        await registrationModel.update({createdBy:Registration.dataValues.id},{where:{
          id:Registration.dataValues.id,
        }});
        Registration.dataValues.createdBy=Registration.dataValues.id;

        //started for admin.
        //check token access or not.
        if(Auth.getAccessToken(req)){
          //get data from token.
          const data=await Auth.getUserData(req);
          //find role data using token role_id.
          const getRoleData=await db.roleModel.findByPk(data.role_id);
          if(getRoleData.role_name=="Admin"){
            
            await registrationModel.update({
              createdBy:data.id
            },{
              where:{
              id:Registration.dataValues.id,
            }
          });
            Registration.dataValues.createdBy=data.id;
          }
          return Helper.respondAsJSON(res,"Registration Successfully.",Registration,true,200);
        }
        return Helper.respondAsJSON(res,"Registration Successfully.",Registration,true,200);
      }else{
        return Helper.respondAsJSON(res,"Register not done yet.",Registration,false, 500);
      }
    } catch (error) {
      console.error("error in catch",error);
      return Helper.handleError(res,500,'Unable to registration',false,error);
    }
  },
};