require("dotenv").config();
const Helper=require("../helper/common.helper");
const db = require("../model/sequelize.model");
const productModel=db.productModel;
const registrationModel=db.registrationModel;
const imageModel=db.imageModel;

module.exports={
    viewProductById:async (req,res)=>{
        try {
            let {product_id}=req.params;
            let product = { where: {}};
            
            if(product_id){
                product.where.product_id=product_id;
                // product.where.status=1;
            }

            let query = {
                where: [product.where],
                include: [{
                    model:imageModel
                },{
                    model: registrationModel,
                    attributes: { exclude: ['password'] },
                }],
                order: [["product_id", "DESC"],],
            };
            const productData=await productModel.findAll({query});
            //check product find or not.
            if(!productData.length){
                return Helper.respondAsJSON(res,"Product not found yet.",productData,false,404);
            }
            return Helper.respondAsJSON(res,"Product view successfully.",productData,true,200);
        } catch (error) {
            console.error("error while catch",error);
            return Helper.handleError(res,500,'Unable to view product.',false,error);
        }
    }
}