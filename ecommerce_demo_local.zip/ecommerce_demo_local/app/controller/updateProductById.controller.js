require("dotenv").config();
let {Sequelize,Op}=require('sequelize');
const Helper=require("../helper/common.helper");
const Auth=require("../helper/auth.helper");
const db = require("../model/sequelize.model");
const productModel=db.productModel;
const imageModel=db.imageModel;
module.exports={
    updateProductById: async(req,res)=>{
        try {
            //get data from body.
            let {product_name,brand_name,product_details,product_rating,product_price,status}=req.body;
            let{product_id}=req.params;
            const updateData=await productModel.update({
                product_name,
                brand_name,
                product_details,
                product_rating,
                product_price,
                status
            },{where:{
                product_id,
            }});
            const data=await productModel.findByPk(product_id);
            if(req.files.length){
                const path = [];
                Object.keys(req.files).forEach((k) => {
                    const file = req.files[k];
                    const product_id=data.product_id;
                    const value = { file,product_id};
                    path.push(value);
                });
                const deleteImageData=await imageModel.destroy({where:{product_id:product_id}});
                const addNewImages=await imageModel.bulkCreate(path.map(v=>({url:v.file.path,product_id:v.product_id})));
                // console.log("addNewImages",addNewImages);
                // console.log("deleteImageData",deleteImageData);
            }
            // const addImage= await imageModel.update(path.map(v=>({url:v})),{where:{product_id}});
            // const url=path.map((v)=>({url:v}));
            // let promises = await Promise.all( path.map(async(data)=>{
            //     const  urlData  = data;
            //     console.log("url",urlData);
            //     const images= await imageModel.update({url: urlData}, { where: { product_id } });
            //     return images;
            // }));
            // return console.log("promises",promises);
            if(updateData){
                return Helper.respondAsJSON(res,"Product update successfully.",data,true,200);
            }
            return Helper.respondAsJSON(res,"Product not update yet.",data,false,404);
        } catch (error) {
            console.error("error while catch",error);
            return Helper.handleError(res,500,'Unable to update product.',false,error);
        }
    }
}