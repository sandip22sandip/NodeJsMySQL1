module.exports = (sequelize, Sequelize) => {
  const cart = sequelize.define("cart", {
    cart_id: {
      type: Sequelize.INTEGER(10),
      autoIncrement: true,
      primaryKey: true,
    },
    id: {
      type: Sequelize.INTEGER(10),
    },
    product_id: {
      type: Sequelize.INTEGER(10),
    },
    product_qty: {
      type: Sequelize.INTEGER(10),
    },
    cart_total: {
      type: Sequelize.INTEGER(10),
    },
    status: {
      type: Sequelize.STRING(5),
      defaultValue: 1,
    },
  });
  return cart;
};
