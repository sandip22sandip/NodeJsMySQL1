module.exports = (sequelize, Sequelize) => {
  const images = sequelize.define("images", {
    image_id: {
      type: Sequelize.INTEGER(10),
      autoIncrement: true,
      primaryKey: true,
    },
    url: {
      type: Sequelize.STRING(100),
    },
    product_id: {
      type: Sequelize.INTEGER(10),
    },
    status: {
      type: Sequelize.STRING(5),
      defaultValue: 1,
    },
  });
  return images;
};
