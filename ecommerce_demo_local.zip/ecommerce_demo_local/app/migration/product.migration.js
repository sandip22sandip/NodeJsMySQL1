module.exports = (sequelize, Sequelize) => {
  const product = sequelize.define("product", {
    product_id: {
      type: Sequelize.INTEGER(10),
      autoIncrement: true,
      primaryKey: true,
    },
    product_name: {
      type: Sequelize.STRING(100),
    },
    brand_name: {
      type: Sequelize.STRING(50),
    },
    product_details: {
      type: Sequelize.STRING(300),
    },
    product_rating: {
      type: Sequelize.INTEGER(5),
    },
    product_price: {
      type: Sequelize.INTEGER(10),
    },
    id: {
      type: Sequelize.INTEGER(10),
    },
    status: {
      type: Sequelize.STRING(5),
      defaultValue: 1,
    },
  });
  return product;
};
