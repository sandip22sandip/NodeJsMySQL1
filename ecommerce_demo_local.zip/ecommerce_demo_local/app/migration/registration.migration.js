module.exports=(sequelize,Sequelize)=>{
    const registration=sequelize.define("registration",{
        id:{
            type:Sequelize.INTEGER(10),
            autoIncrement: true,
            primaryKey: true,
        },
        first_name:{
            type:Sequelize.STRING,
        },
        last_name:{
            type:Sequelize.STRING,
        },
        email:{
            type:Sequelize.STRING,
            unique: true,
        },
        gender:{
            type:Sequelize.STRING,
        },
        contact_no:{
            type:Sequelize.BIGINT(10),
        },
        password:{
            type:Sequelize.STRING,
        },
        role_id:{
            type:Sequelize.INTEGER(10),
        },
        createdBy:{
            type:Sequelize.STRING(10),
        },
        status:{
            type:Sequelize.STRING(10),
            defaultValue: 1,
        },
        token:{
            type:Sequelize.STRING(500),
        },
    });
    return registration;
}
