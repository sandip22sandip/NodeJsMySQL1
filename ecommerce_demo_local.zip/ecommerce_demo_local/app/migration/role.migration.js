module.exports=(sequelize,Sequelize)=>{
    const role=sequelize.define("role",{
        role_id:{
            type:Sequelize.INTEGER(10),
            autoIncrement: true,
            primaryKey: true,
        },
        role_name:{
            type:Sequelize.STRING(50),
        },
        status:{
            type:Sequelize.STRING(10),
            defaultValue: 1,
        }
    });
    return role;
}