const jwt = require("jsonwebtoken");
const db = require("../model/sequelize.model");
const Helper = require("../helper/common.helper");
const registrationModel = db.registrationModel;

function getAccessTokenFromHeader(req) {
  return req.headers["authorization"] && req.headers["authorization"] !== null
    ? req.headers["authorization"].split(" ")[1]
    : null;
}

module.exports = {
  getAccessToken: (req) => {
    return getAccessTokenFromHeader(req);
  },

  getUserData: async (req, res, next) => {
    let tokenfromheader = getAccessTokenFromHeader(req);
    return jwt.verify(tokenfromheader, process.env.JWT_KEY);
  },

  ensure: async (req, res, next) => {
    let tokenfromheader = getAccessTokenFromHeader(req);
    if (tokenfromheader === null) {
      Helper.handleError(res, 401, "UnAthorize access.", false, {});
    } else {
      let Data = await registrationModel.findOne({ token: tokenfromheader });
      if (Data) {
        next();
      } else {
        Helper.handleError(res, 401, "UnAthorize access.", false, {});
      }
    }
  },
  
  authorize: async(req,res,next)=>{
    let tokenfromheader = getAccessTokenFromHeader(req);
    if (tokenfromheader === null) {
      Helper.handleError(res, 401, "UnAthorize access.", false, {});
    }else{
      let Data = jwt.verify(tokenfromheader, process.env.JWT_KEY);
      if(Data.role_id==1){
        const adminData=await registrationModel.findByPk(Data.id);
        if(adminData){
          // console.log("data",adminData);
          next();
        }
      }else{
        Helper.handleError(res, 401, "UnAthorize access only admin can access.", false, {});
      }
    }
  }
};