const { body } = require("express-validator");

exports.validate = (method) => {
  switch (method) {
    case "registration": {
      return [
        body("first_name")
          .notEmpty()
          .withMessage("Field is mandatory.")
          .trim()
          .escape()
          .isLength({ min: 2, max: 50 })
          .withMessage("Minimum 2 characters required.")
          .isAlpha()
          .withMessage("Must use alphabet in name."),
        body("last_name")
          .notEmpty()
          .withMessage("Field is mandatory.")
          .trim()
          .escape()
          .isLength({ min: 2, max: 50 })
          .withMessage("Minimum 2 characters required.")
          .isAlpha()
          .withMessage("Must use alphabet in name."),
        body("email", "Invalid email.")
          .notEmpty()
          .withMessage("Email should not be empty.")
          .isEmail()
          .normalizeEmail()
          .isLowercase()
          .withMessage("Must be all small letters."),
        body("gender")
          .notEmpty()
          .withMessage("Gender should not be empty.")
          .isIn(["Male", "Female"])
          .withMessage("Only Male & Female gender accepted."),
        body("role")
          .notEmpty()
          .withMessage("Type should not be empty.")
          .isIn(["User", "Vendor","Admin"])
          .withMessage("Only user & vendor type accepted."),
        body("contact_no")
          .isNumeric()
          .withMessage("Contact Number Must be a numeric.")
          .isLength({ max: 10, min: 10 })
          .withMessage("Enter Mobile Number with 10 Digit."),
        body("password")
          .notEmpty()
          .withMessage("Password should not be empty.")
          .isLength({ min: 6, max: 10 })
          .withMessage("Password must be greater than 6 and less then 10.")
          .isStrongPassword({
            minLowercase: 1,
            minUppercase: 1,
            minNumbers: 1,
          })
          .trim()
          .withMessage(
            "Password must be 1 lowercase letter, 1 special letter, and 1 number."
          ),
      ];
    }
    case "login": {
      return [
        body("email", "Invalid email.")
          .notEmpty()
          .withMessage("Email should not be empty.")
          .isEmail()
          .normalizeEmail()
          .isLowercase()
          .withMessage("Must be all small letters."),
        body("password")
          .notEmpty()
          .withMessage("Password should not be empty.")
          .isLength({ min: 6, max: 10 })
          .withMessage("Password must be greater than 6 and less then 10.")
          .isStrongPassword({
            minLowercase: 1,
            minUppercase: 1,
            minNumbers: 1,
          })
          .trim()
          .withMessage(
            "Password must be 1 lowercase letter, 1 special letter, and 1 number."
          ),
      ];
    }
    case "changepassword": {
      return [
        body("oldpassword")
          .isLength({ min: 6, max: 10 })
          .withMessage("Password must be greater than 6 and less then 10.")
          .isStrongPassword({
            minLowercase: 1,
            minUppercase: 1,
            minNumbers: 1,
          })
          .trim()
          .withMessage(
            "Password must be 1 lowercase letter, 1 special letter, and 1 number."
          ),
        body("newpassword")
          .isLength({ min: 6, max: 10 })
          .withMessage("Password must be greater than 6 and less then 10.")
          .isStrongPassword({
            minLowercase: 1,
            minUppercase: 1,
            minNumbers: 1,
          })
          .trim()
          .withMessage(
            "Password must be 1 lowercase letter, 1 special letter, and 1 number."
          ),
      ];
    }
  }
};
