const sequelize=require('../db/sequelize.connection');
const Sequelize=require("sequelize");

const db={};
db.sequelize=sequelize;
db.Sequelize=Sequelize;
db.registrationModel=require('../migration/registration.migration')(sequelize,Sequelize);
db.productModel=require('../migration/product.migration')(sequelize,Sequelize);
db.cartModel=require('../migration/cart.migration')(sequelize,Sequelize);
db.imageModel=require('../migration/images.migration')(sequelize,Sequelize);
db.roleModel=require('../migration/role.migration')(sequelize,Sequelize);

sequelize.sync();
// sequelize.sync({force:true});

//make foreign key 
//assign registration id in product as a foreign key,
db.roleModel.hasMany(db.registrationModel,{ foreignKey: 'role_id' });
db.registrationModel.belongsTo(db.roleModel,{ foreignKey: 'role_id' });

//assign registration id in product as a foreign key,
db.registrationModel.hasMany(db.productModel,{ foreignKey: 'id' });
db.productModel.belongsTo(db.registrationModel,{ foreignKey: 'id' });

//assign registraion id in cart table as a foreign key,
db.registrationModel.hasMany(db.cartModel,{ foreignKey: 'id' });
db.cartModel.belongsTo(db.registrationModel,{ foreignKey: 'id' });

//assign product_id in cart table as a foreign key,
db.productModel.hasMany(db.cartModel,{ foreignKey: 'product_id' });
db.cartModel.belongsTo(db.productModel,{ foreignKey: 'product_id' });

//assign product_id in image table as a foreignkey.
db.productModel.hasMany(db.imageModel,{foreignKey:'product_id'});
db.imageModel.belongsTo(db.productModel,{foreignKey:'product_id'});
module.exports=db;